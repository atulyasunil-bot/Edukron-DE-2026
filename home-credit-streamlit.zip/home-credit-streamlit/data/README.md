# Data Folder

Place the raw Home Credit CSV files here before running the app or notebooks:

- application_train.csv
- application_test.csv
- bureau.csv
- bureau_balance.csv
- POS_CASH_balance.csv
- previous_application.csv        (optional — enables page 15)
- installments_payments.csv       (optional — enables page 17)
- credit_card_balance.csv         (optional — enables page 18)

Files are excluded from the project package to keep the download lightweight. The app and notebooks read
directly from this folder using relative paths, so no code changes are needed once the files are added.
