# Home Credit — 20-Page EDA & Preprocessing Streamlit Dashboard

## Project Objective
A pure **exploratory data analysis, data-cleaning, and feature-engineering** dashboard built on the Home
Credit Default Risk dataset. **No machine-learning model is trained, evaluated, or deployed anywhere in this
project.** Every chart, KPI, and "risk segment" is derived directly from cleaned and engineered data using
transparent, documented rules.

## Business Problem
Home Credit extends loans to customers with limited or no formal credit history. Before any predictive
modelling is considered, the business needs a trustworthy, explorable view of: who its customers are, how
clean the data is, which affordability and repayment patterns exist, and what actions could reduce risk
today using only descriptive analysis.

## Dataset & Relationships
| File | Grain | Key |
|---|---|---|
| `application_train.csv` / `application_test.csv` | 1 row per loan application | `SK_ID_CURR` |
| `bureau.csv` | 1 row per external credit bureau record | `SK_ID_CURR`, `SK_ID_BUREAU` |
| `bureau_balance.csv` | 1 row per bureau record per month | `SK_ID_BUREAU` |
| `POS_CASH_balance.csv` | 1 row per previous POS/cash loan per month | `SK_ID_CURR`, `SK_ID_PREV` |
| `previous_application.csv` *(optional, not in this upload)* | 1 row per previous Home Credit application | `SK_ID_CURR`, `SK_ID_PREV` |
| `installments_payments.csv` *(optional, not in this upload)* | 1 row per scheduled installment | `SK_ID_CURR`, `SK_ID_PREV` |
| `credit_card_balance.csv` *(optional, not in this upload)* | 1 row per credit card account per month | `SK_ID_CURR`, `SK_ID_PREV` |

```
application_train / application_test
        | SK_ID_CURR
        |------------------------------------------------|
        v                                                  v
     bureau.csv                                      POS_CASH_balance.csv
        | SK_ID_BUREAU
        v
   bureau_balance.csv
```

Pages 15, 17, and 18 (previous applications, installments, credit card) automatically detect whether their
source CSV is present in `data/` and show a clear placeholder + instructions if it is not, rather than
failing.

## Technology Stack
Python · Pandas · NumPy · Streamlit · Plotly Express / Graph Objects · Matplotlib · Jupyter · VS Code · Git

## Project Structure
```
home-credit-streamlit/
├── app.py                      # Landing page / navigation overview
├── requirements.txt
├── README.md
├── data/                       # Symlinked/copied raw CSVs
├── notebooks/
│   ├── 01_data_understanding.ipynb
│   ├── 02_preprocessing.ipynb
│   ├── 03_feature_engineering.ipynb
│   └── 04_eda.ipynb
├── pages/                      # 20 Streamlit analytical pages (01–20)
└── utils/
    ├── data_loader.py          # Cached CSV readers
    ├── preprocessing.py        # Missing-value / duplicate / outlier helpers
    ├── feature_engineering.py  # All engineered features (age, income, ratios, aggregates)
    ├── filters.py              # Shared sidebar filter widgets
    ├── charts.py                # Plotly chart wrappers (consistent styling)
    └── metrics.py               # Number formatting + KPI helpers
```

## Preprocessing Steps (see `notebooks/02_preprocessing.ipynb`)
1. **Data understanding** — shape, dtypes, describe, sample.
2. **Missing values** — per-column count/percentage, bucketed into 0-5% / 5-20% / 20-40% / 40-60% / 60%+,
   each with a documented treatment decision (drop, median/mode fill, missing-indicator, or "Unknown"
   category).
3. **Duplicate analysis** — full-row duplicates and `SK_ID_CURR` uniqueness checks.
4. **Data type correction** — `DAYS_BIRTH` / `DAYS_EMPLOYED` converted from negative day counts to positive
   year-based features; the `DAYS_EMPLOYED == 365243` sentinel (Home Credit's "pensioner/not employed"
   convention) is recoded to `NaN` rather than treated as a numeric outlier.
5. **Outlier analysis** — IQR-based flagging (not silent deletion) with a business-rule classification of
   "true extreme customer" vs. "data-entry issue" vs. "potential invalid value."

## Feature Engineering (see `notebooks/03_feature_engineering.ipynb` and `utils/feature_engineering.py`)
- `AGE_YEARS`, `AGE_GROUP`
- `EMPLOYMENT_YEARS`, `EMPLOYMENT_GROUP`
- `INCOME_GROUP` (quantile-based), `INCOME_PER_FAMILY_MEMBER`, `INCOME_PER_CHILD`
- `CREDIT_TO_INCOME`, `ANNUITY_TO_INCOME`, `GOODS_TO_INCOME`, `CREDIT_TO_GOODS`
- Customer-level bureau aggregates: `BUREAU_ACCOUNT_COUNT`, `ACTIVE_BUREAU_COUNT`, `TOTAL_BUREAU_DEBT`,
  `MAX_BUREAU_OVERDUE`, etc.
- Customer-level POS/CASH aggregates: `AVG_DPD`, `MAX_DPD`, `TOTAL_DPD_EVENTS`, `COMPLETED_CONTRACTS`, etc.

## The 20 Dashboard Pages
| # | Page | Focus |
|---|---|---|
| 01 | Executive Portfolio Overview | Portfolio-wide KPIs and headline charts |
| 02 | Data Quality Dashboard | Row/column counts, dtype mix, completeness gauge |
| 03 | Missing Value Analysis | Missingness buckets and per-column treatment plan |
| 04 | Outlier & Distribution Analysis | IQR flags, box plots, business-rule classification |
| 05 | Customer Demographics | Age, gender, education, family status |
| 06 | Income Analysis | Income groups, affordability by segment |
| 07 | Employment Analysis | Employment tenure, occupation, organization risk |
| 08 | Family & Housing Analysis | Household size, ownership, affordability |
| 09 | Current Loan Application Analysis | Contract type, amounts, timing patterns |
| 10 | Credit Affordability Analysis | Credit/annuity/goods-to-income ratios |
| 11 | Default Risk EDA | TARGET distribution, count vs. rate distinction |
| 12 | Risk Factor Exploration | Banded default rates, correlation heatmap |
| 13 | Bureau Credit History | External credit accounts and debt |
| 14 | Bureau Balance Analysis | Monthly bureau account status trends |
| 15 | Previous Applications | Prior Home Credit applications *(optional file)* |
| 16 | POS/CASH Loan Analysis | POS/cash balance and DPD patterns |
| 17 | Installment Payment Analysis | Repayment timing and amount behaviour *(optional file)* |
| 18 | Credit Card Balance Analysis | Utilization and repayment *(optional file)* |
| 19 | Customer Risk Segmentation | Transparent, rule-based EDA segments (not a model) |
| 20 | Executive Insights & Recommendations | Top findings + 15+ actionable recommendations |

## EDA Methodology
Every analytical page follows: **Business Objective → Sidebar Filters → KPI Cards → 4–8 Charts → Detailed
Data Table → Key Observations → Business Recommendations.** Univariate, bivariate, and multivariate
techniques are demonstrated across the page set (see `notebooks/04_eda.ipynb` for a static walkthrough).

## Major Insights
See page 20 (Executive Insights & Recommendations) inside the app, and the accompanying project PDF, for
the full list of 10+ findings and 15+ business recommendations.

## Installation
```bash
cd home-credit-streamlit
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
```
Place the raw Home Credit CSVs into the `data/` folder (see the table above for expected filenames).

## How to Run
```bash
streamlit run app.py
```
Then use the sidebar page navigator to move between the 20 pages.

## Notebooks
Open any notebook under `notebooks/` in Jupyter or VS Code:
```bash
jupyter notebook notebooks/01_data_understanding.ipynb
```

## Important Project Rule
No logistic regression, random forest, XGBoost, LightGBM, neural networks, ROC curves, confusion matrices,
SHAP, or feature-importance models are used anywhere in this project. The scope stops at: **Data →
Preprocessing → Feature Engineering → EDA → Segment Analysis → Observed Risk Patterns → Business Insights →
Business Recommendations.**

## Author / Project Profile

| Field | Details |
|---|---|
| Name | *(add your name)* |
| Roll No. / Student ID | *(add your ID)* |
| Course / Program | *(add your course)* |
| Institution | *(add your college/university)* |
| Email | *(add your email)* |
| GitHub | *(add your repo link)* |
| Submission Date | *(add date)* |

Project: Home Credit 20-Page Streamlit EDA & Preprocessing Dashboard.
